#!/bin/bash
cd "$(dirname "$0")"
echo "🚀 Starting BootForge GUI..."
python3 main.py --gui
